                    <footer class="footer">
                        <div class="d-sm-flex justify-content-center justify-content-sm-between">
                            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block"><a>Copyright © <?php echo date('Y'); ?>.  Created by @Koarmada 2</a></span>
                        </div>
                    </footer>
                </div>
            </div>
        </div>

        <script src="<?php echo base_url(); ?>/vendors/js/vendor.bundle.base.js"></script>
        <script src="<?php echo base_url(); ?>/vendors/chart.js/Chart.min.js"></script>
        <script src="<?php echo base_url(); ?>/vendors/datatables.net/jquery.dataTables.js"></script>
        <script src="<?php echo base_url(); ?>/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
        <script src="<?php echo base_url(); ?>/js/dataTables.select.min.js"></script>
        <script src="<?php echo base_url(); ?>/js/off-canvas.js"></script>
        <script src="<?php echo base_url(); ?>/js/hoverable-collapse.js"></script>
        <script src="<?php echo base_url(); ?>/js/template.js"></script>
        <script src="<?php echo base_url(); ?>/js/settings.js"></script>
        <script src="<?php echo base_url(); ?>/js/todolist.js"></script>
        <script src="<?php echo base_url(); ?>/js/dashboard.js"></script>
        <script src="<?php echo base_url(); ?>/js/Chart.roundedBarCharts.js"></script>
    </body>

</html>